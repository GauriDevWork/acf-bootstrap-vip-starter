// Delete the flexible content preview popup if only one layout

jQuery(document).ready(function (jQuery) {
  if (typeof acf !== 'undefined') {
    var flexible_content_open = acf.getField('acf-field-flexible-content');
    flexible_content_open._open = function (e) {
      var $popup = jQuery(this.$el.children('.tmpl-popup').html());
      if ($popup.find('a').length == 1) {
        // Only one layout
        flexible_content_open.add($popup.find('a').attr('data-layout'));
        return false;
      }
      return flexible_content_open.apply(this, arguments);
    }
  }
});

// Transform a link into a div for styling purpose
jQuery('body').on('click', 'a[data-name="add-layout"]', function() {
     // Add custom class
    jQuery('.acf-fc-popup').addClass('acf-fc-popup-module');
    jQuery('.acf-fc-popup.acf-fc-popup-module a').each(function() {
      var html = '<div class="acf-fc-popup-label">' + jQuery(this).text() + '</div><div class="acf-fc-popup-image"></div>';
      jQuery(this).html(html);
    });
});

// Remove custom class when a layout is chosen
jQuery('body').on('click', '.acf-fc-popup.acf-fc-popup-module a[data-layout]', function ($) {
  $(this).closest('.acf-fc-popup').removeClass('acf-fc-popup-module');
});